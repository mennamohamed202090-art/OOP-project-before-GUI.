package DAO;
import java.util.Scanner;
import java.util.ArrayList;

import ENTITY.User.*;
import Database.Database;
import Service.*;
import ENTITY.Sprint.Sprint;



public class UserDAO 
{
    public static User add_user() /*Registeration Process */
    {
        User user= new Developer();
        boolean RepeatedUsername = true;
        String user_name = "none";
        Scanner input = new Scanner(System.in);
        System.out.println("Enter the role of the user (Developer, QAEngineer, Stakeholder, ScrumMaster)");
        String user_role = input.next().trim();
        System.out.println("Enter the name of the user");
        String name = input.next();
        while (RepeatedUsername)
        {
            System.out.println("Enter the username of the user");
            String user_name_check = input.next().trim();
            if (Database.getUsers().size() == 0)
            {
                user_name = user_name_check;
                RepeatedUsername = false;
            }
            else 
            {
                boolean UserNameExist = false;
                for( int i = 0 ; i < Database.getUsers().size() ; i++)
                {
                    if (Database.getUsers().get(i).getUsername().equals(user_name_check))
                    {
                        System.out.println("This username has been used. Try another one.");
                        RepeatedUsername = true;
                        UserNameExist = true;
                    }
                }
                if (UserNameExist == false)
                {
                    user_name = user_name_check;
                    RepeatedUsername = false;
                }
            } 
        }
        System.out.println("Enter the password of the user");
        String user_password = input.next().trim();
        if (user_role.equalsIgnoreCase("Developer"))
        {
            user = new Developer(name, user_name , user_password);
            DeveloperWindow((Developer) user);
        }
        else if(user_role.equalsIgnoreCase("QAEngineer"))
        {
            user = new QAEngineer(name, user_name , user_password);
        }
        else if(user_role.equalsIgnoreCase("Stakeholder"))
        {
            user = new Stakeholder(name, user_name , user_password);
            Stakeholder_addRequest_reviewRequest((Stakeholder) user);

        }
        else if(user_role.equalsIgnoreCase("ScrumMaster"))
        {
            user = new ScrumMaster(name, user_name , user_password);
            ScrumMaster_Window((ScrumMaster) user);
        }
        else
        {
            System.out.println("You chose a wrong role.");
        }
     return user;
    }

    public static void login() /*Login Process */
    {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter your username");
        String username = input.next().trim();
        boolean not_registerd = true;
        ArrayList<User> users = Database.getUsers();
        for(int i = 0 ; i < users.size() ; i++)      /*Loop to search for the username in the Database (usernames ArrayList) */
        {
           if( ((users.get(i)).getUsername()).equals(username) ) /*check if the username is equal to any of the usernames in the Database */
           {
                not_registerd = false;
                System.out.println("Enter your password");
                String password = input.next();
                if (((users.get(i)).getPassword()).equals(password) ) /*check if the password of the username is right */
                {
                    System.out.println("You logged in successfully");
                    if(users.get(i) instanceof Stakeholder)
                    {
                        Stakeholder_addRequest_reviewRequest((Stakeholder) (users.get(i)));
                    }
                    else if(users.get(i) instanceof ScrumMaster)
                    {
                        ScrumMaster_Window((ScrumMaster) users.get(i));
                    }
                    else if(users.get(i) instanceof Developer)
                    {
                        DeveloperWindow((Developer) users.get(i));
                    }

                }
                else
                {
                    System.out.println("You have entered wrong password");
                }
           }  
        }

        if (not_registerd)
        {
            System.out.println("You are not registerd yet");
        }

    }

    /* Stakeholder window */
    private static void Stakeholder_addRequest_reviewRequest( Stakeholder stakeholder) 
    {
        boolean status = true;
        while(status)
        {
            Scanner input = new Scanner(System.in);
            System.out.println("Would you like to add or review a request. Choose ( add or review) ");
            String choice = input.next().trim();
            if(choice.equalsIgnoreCase("add")) /*Add or Create Request */
            {
                Scanner input_request = new Scanner(System.in);
                System.out.println("Enter your request. ");
                String request = input_request.nextLine();
                stakeholder.createRequest(request);
            }
            else if( choice.equalsIgnoreCase("review")) /*Review Request */
            {
                Scanner scanner = new Scanner(System.in);
                System.out.println("Enter your request number. ");
                int request_number = scanner.nextInt();
                stakeholder.viewRequest(request_number);
            } 

            Scanner scanner = new Scanner(System.in);
            System.out.println("Do you want to exit the add and review request window? ( yes or no )");
            String stats_value = scanner.next().trim();
            if(stats_value.equalsIgnoreCase("yes"))
            {
                status = false;
            }
        }
          
    }  
    
    /* Scrum Master Window */
    private static void ScrumMaster_Window(ScrumMaster scrumMaster)
    {
        boolean window_status = true;
        while (window_status)                                     /* to keep the scrum Master window until he close it */
        {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Choose one of these options. ( Create Sprint, Edit Sprint, Exit )");
            String status_value = scanner.nextLine().trim();
            if (status_value.equalsIgnoreCase("Create Sprint")) /* to create a sprint */
            {
                int sprint_number = WorkItemService.Create_Sprint(scrumMaster); /* to get the sprint number been created to use it to fill the rest of the sprint attributes if the user want to */
                boolean Create_Sprint_Window = true;
                while(Create_Sprint_Window)                                     /* to give the scrum master the options to assign team or add epic to the sprint right after creating the sprint */
                {
                    Sprint sprint = Database.getSprints().get( sprint_number - 1);
                    System.out.println("Choose one of these options. ( Assign Team, Add Epic, Add Task, Assign Task to developer, Change Task Status, Exit )");
                    Scanner input = new Scanner(System.in);
                    String status_value1 = input.nextLine().trim();
                    if (status_value1.equalsIgnoreCase("Assign Team")) /* to assign team to the sprint */
                    {
                        WorkItemService.add_team(sprint, scrumMaster);
                    }
                    else if (status_value1.equalsIgnoreCase("Add Epic")) /* to add epic to the sprint */
                    {
                        WorkItemService.add_epics(sprint);
                    }
                    else if (status_value1.equalsIgnoreCase("Add Task")) /* to add task to the sprint */
                    {
                        WorkItemService.add_tasks(sprint);
                    }
                    else if (status_value1.equalsIgnoreCase("Assign Task to developer")) /* to assign task in the sprint to a developer*/
                    {
                        WorkItemService.assign_tasks(sprint);
                    }
                    else if (status_value1.equalsIgnoreCase("Change Task Status")) /* to assign task in the sprint to a developer*/
                    {
                        WorkItemService.change_tasks_status_scrumMaster(sprint);
                    }

                    else if (status_value1.equalsIgnoreCase("Exit")) /* to exit the create sprint window */
                    {
                        
                        Create_Sprint_Window = false;
                    }
                    else                                                             /* to check invalidity */
                    {
                        System.out.println(" You have entered an invalid input. Try Again");
                    }

                }
            }
            else if (status_value.equalsIgnoreCase("Edit Sprint")) /* to edit a sprint */
            {
                System.out.println("Enter the number of the sprint you want to edit.");
                Scanner input_int = new Scanner(System.in);
                int sprint_number = input_int.nextInt();
                if(sprint_number <=(Database.getSprints()).size()) /* to check if the sprint is already created */
                {
                    Sprint sprint = (Database.getSprints()).get(sprint_number - 1); /* to get the sprint from the Database */
                    boolean window_status1 = true;
                    while (window_status1)
                    {
                        System.out.println("Choose one of these options. ( Assign Team, Add Epic, Add Task, Assign Task to developer, Change Task Status, Exit )");
                        Scanner input = new Scanner(System.in);
                        String status_value1 = input.nextLine().trim();
                        if (status_value1.equalsIgnoreCase("Assign Team")) /* to assign team to the sprint */
                        {
                           WorkItemService.add_team(sprint, scrumMaster);
                        }
                        else if (status_value1.equalsIgnoreCase("Add Epic")) /* to add epic to the sprint */
                        {
                            WorkItemService.add_epics(sprint);
                        }
                        else if (status_value1.equalsIgnoreCase("Add Task")) /* to add task to the sprint */
                        {
                            WorkItemService.add_tasks(sprint);
                        }
                        else if (status_value1.equalsIgnoreCase("Assign Task to developer")) /* to assign task in the sprint to a developer*/
                        {
                            WorkItemService.assign_tasks(sprint);
                        }
                        else if (status_value1.equalsIgnoreCase("Change Task Status")) /* to assign task in the sprint to a developer*/
                        {
                            WorkItemService.change_tasks_status_scrumMaster(sprint);
                        }
                        else if (status_value1.equalsIgnoreCase("Exit")) /* to exit the add epic window */
                        {
                            window_status1 = false;
                        }
                        else                                                             /* to check invalidity */
                        {
                            System.out.println(" You have entered an invalid input. Try Again");
                        }

                    }
                }
                else                                                                       /* to show the user that this sprint is not created yet */
                {
                    System.out.println("This sprint has not been created yet.");
                }
                
            }
            else if (status_value.equalsIgnoreCase("Exit")) /* to exit the scrum master window */
            {
                window_status = false;
            }
            else                                                            /* to check invalidity */
            {
                System.out.println("You have entered an invalid input. Try Again");
            }
        }
    }

    /* Developer Window */
    private static void DeveloperWindow( Developer developer)
    {
        boolean DeveloperWindow = true;
        while(DeveloperWindow)                                               /* to keep the Developer Window open until the developer closes it */
        {
            System.out.println("Choose one of these options. ( Review Tasks, Change Task Status, Exit )");
            Scanner input = new Scanner(System.in);
            String option = input.nextLine().trim();
            if (option.equalsIgnoreCase("Review Tasks"))        /* to allow the developer to review the tasks assigned to him */
            {
                WorkItemService.review_tasks_developer(developer);
            }
            else if (option.equalsIgnoreCase("Change Task Status"))      /* to allow the developer to change the status of the tasks assigned to him */
            {
                WorkItemService.change_tasks_status_developer(developer);
            }
            else if (option.equalsIgnoreCase("Exit"))                    /* to allow the developer to choose ot exit the Developer window */
            {
                DeveloperWindow = false;
            }
            else
            {
                System.out.println("You have just entered an invalid input.Try Again");
            }


        }
    }
}
