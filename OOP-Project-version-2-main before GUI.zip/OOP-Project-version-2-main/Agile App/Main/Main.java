package Main;
import java.util.ArrayList;
import java.util.Scanner;

import DAO.UserDAO;
import Service.*;
import Database.Database;
import ENTITY.User.User;

public class Main {
    public static void main(String arg[])
    {
        boolean repeat = true;
        Scanner input = new Scanner(System.in);
        while( repeat) /*Keep the login and registration window open until user exits */
        {
            boolean invalid = true;
            while (invalid)              /* check validity of user input */
            {
                System.out.println("Would you like to register or login ( Choose register or login )");/*app starting */
                String choice = input.next();
                if( choice.equalsIgnoreCase("register") ) /*IF user choose to register */
                {
                    invalid = false;
                    User user1 = UserService.User_Registeration();                    /*Registeration Process */

                    System.out.println("User id: " + user1.getId() + " User name: " + user1.getName() + " User username " + user1.getUsername());
                }
                else if( choice.equalsIgnoreCase("login") ) /*If user choose to login */
                {
                    invalid = false;
                    UserService.User_login();                             /*Login Process*/
                }
                else
                {
                    System.out.println("You have entered an invalid input. Try Again");
                    invalid = true;
                }
            }
            
            boolean invalid1 = true;
            while (invalid1)
            {
                System.out.println("Would you like to login or register again ( yes or no ) ?"); /*Asking to keep the Login and Registration window open */
                String continuity = input.next();
                if(continuity.equalsIgnoreCase("no"))
                {
                    repeat = false;
                    invalid1 = false;
                }
                else if(continuity.equalsIgnoreCase("yes"))
                {
                    repeat = true;
                    invalid1 = false;
                }
                else 
                {
                    System.out.println("You have entered an invalid input. Try Again");
                    invalid1 = true;
                }

            }
            
        }
  
    }  
}
