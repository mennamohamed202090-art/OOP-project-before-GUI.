package controllers;

public class WelcomeController {
}
