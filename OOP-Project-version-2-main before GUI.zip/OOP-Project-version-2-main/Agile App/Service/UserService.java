package Service;
import java.util.ArrayList;
import DAO.UserDAO;
import Database.Database;
import ENTITY.User.*;
public class UserService {
    public static User User_Registeration() /*calls the registration process */
    {

        return UserDAO.add_user();
    }
    public static void User_login()          /*calls the Login process */
    {
        UserDAO.login();
    }
 
}
