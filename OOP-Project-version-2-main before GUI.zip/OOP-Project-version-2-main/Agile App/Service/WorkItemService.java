package Service;
import java.util.Scanner;

import ENTITY.Sprint.Sprint;
import ENTITY.User.Developer;
import ENTITY.User.ScrumMaster;
import ENTITY.WorkItem.*;
public class WorkItemService {
    public static void add_epics(Sprint sprint) /* allow Scrum Master to add epics to the Sprint */
    {
        sprint.set_epics();
    }
    public static int Create_Sprint(ScrumMaster scrumMaster) /* allow Scrum Master to create Sprint to the Sprint */
    {
    int sprint_number = scrumMaster.planSprint();
    return sprint_number;
    }
    public static void add_team(Sprint sprint , ScrumMaster scrumMaster) /* allow Scrum Master to add team to the Sprint */
    {
        sprint.assignTeam(scrumMaster);
    }
    public static void add_tasks(Sprint sprint)                             /* allow Scrum Master to add tasks to the Sprint */
    {
        sprint.addTask();
    }
    public static void assign_tasks(Sprint sprint)                         /* allow Scrum Master to assign tasks to developers in the Sprint */
    {
        sprint.assignTask();
    }
    public static void change_tasks_status_scrumMaster(Sprint sprint)
    {
        sprint.ChangeTaskStatus();
    }
    public static void review_tasks_developer(Developer developer)
    {
        developer.ReviewTasks();
    }
    public static void change_tasks_status_developer(Developer developer)
    {
        developer.ChangeTaskStatus();
    }
}
