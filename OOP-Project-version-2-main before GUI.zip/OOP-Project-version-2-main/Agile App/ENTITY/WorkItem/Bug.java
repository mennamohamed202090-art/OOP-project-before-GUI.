package ENTITY.WorkItem;

public class Bug extends WorkItem {

    public Bug(String title, String description) {
        super(title, description);
    }

}
