package ENTITY.WorkItem;
import java.util.ArrayList;

public class Story extends Epic {

    private ArrayList<Task> subTasks = new ArrayList<>();

    public Story(String title, String description) {
        super(title, description);
    }

    public void addTask(Task task) {
        subTasks.add(task);
    }

    public ArrayList<Task> getSubTasks() {
        return subTasks;
    }
}
