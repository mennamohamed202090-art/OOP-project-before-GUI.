package ENTITY.WorkItem;
import ENTITY.User.*;

public class Task extends Story 
{
    private String TaskStatus = "not decided yet";
    String DeveloperAssigned = "none" ;

    public Task(String title, String description) 
    {
        super(title, description);
    }

    public void set_TaskStatus(String TaskStatus)
    {
        this.TaskStatus = TaskStatus;
        System.out.println("The status of this task now is "+ this.TaskStatus);
    }
    
    public String get_TaskStatus()
    {
        return TaskStatus;
    }

    public void set_DeveloperAssigned(Developer developer)
    {
        DeveloperAssigned = developer.getName();
    }

    public String get_DeveloperAssigned()
    {
        return DeveloperAssigned;
    }




}
