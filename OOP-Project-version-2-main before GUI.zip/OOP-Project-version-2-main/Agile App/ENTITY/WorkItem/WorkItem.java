package ENTITY.WorkItem;
import Database.Database;
import ENTITY.User.*;

public abstract class WorkItem 
{
    private static int  id_generator;
    private int id;
    protected String title;
    private String description;
    private String status;
    private User assignedTo;

    public WorkItem(String title, String description) {
        this.id = id_generator + 1;
        this.title = title;
        this.description = description;
        this.status = "New";
        id();
        add_workitems_to_bug_epic_story_task_arraylists(this); /*Give the item automatically to its right ArrayList in the Database class */
    }

    public void add_workitems_to_bug_epic_story_task_arraylists(WorkItem item) /*Add items in their right ArrayList (epics, stories, tasks, bugs) in the Database class */
    {
        if (item instanceof Bug)
        {
            Database.addBug((Bug)item);
        }
        else if (item instanceof Epic)
        {
            Database.addEpic((Epic)item);
        }
        else if (item instanceof Story)
        {
            Database.addStory((Story)item);
        }
        else if (item instanceof Task)
        {
            Database.addTask((Task)item);
        }
    }

    public static int id() /*to set the id automatically */
    {
        id_generator +=1;
        return id_generator;
    }

    public int getId()
    { 
        return id; 
    }
    public String getTitle() 
    { 
        return title;
    }
    public String getDescription() 
    { 
        return description; 
    }
    public String getStatus()
    {
        return status; 
    }
    public User getAssignedTo() 
    { 
        return assignedTo;
    }

    public void setTitle(String title) { this.title = title; }
    public void setDescription(String description) { this.description = description; }

    public void assignTo(User user) {
        this.assignedTo = user;
    }

    public void updateStatus(String newStatus) {
        this.status = newStatus;
    }
}




