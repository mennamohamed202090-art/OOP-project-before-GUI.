package ENTITY.WorkItem;
import java.util.ArrayList;

public class Epic extends WorkItem {

    private ArrayList<Story> stories = new ArrayList<>();

    public Epic( String title, String description) {
        super(title, description);
    }

    public void addStory(Story story) {
        stories.add(story);
    }

    public ArrayList<Story> getStories() {
        return stories;
    }
}

