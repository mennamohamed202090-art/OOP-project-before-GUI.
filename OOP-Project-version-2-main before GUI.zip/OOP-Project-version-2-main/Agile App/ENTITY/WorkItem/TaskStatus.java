package ENTITY.WorkItem;

public interface TaskStatus
{
    public void ChangeTaskStatus();
}
