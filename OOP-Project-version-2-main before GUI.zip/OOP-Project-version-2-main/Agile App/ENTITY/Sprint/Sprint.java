package ENTITY.Sprint;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

import Service.WorkItemService;
import Database.Database;
import ENTITY.WorkItem.*;
import ENTITY.User.*;

public class Sprint implements TaskStatus
{
    private Date startDate;
    private Date endDate;
    private String objective;
    private String assignedTeam;
    private ArrayList<Epic> epics = new ArrayList<>();
    private ArrayList<Task> tasks = new ArrayList<>();
    private ArrayList<Task> TasksAssignedToDeveloper = new ArrayList<>();


    public Sprint(String objective)
    {
        this.objective = objective;
        setdates();
        add_sprint_to_sprints_ArrayList(this);
    }

    public void add_sprint_to_sprints_ArrayList(Sprint sprint) /* Add the sprint in the Database in the sprint Arraylist */
    {
        Database.addSprint(sprint);
    }

    public void addTask()
    {
        boolean window_open = true;
        while(window_open) /* to make the user choose if he wants to keep the window of adding tasks opened */
        {
            System.out.println("Enter the title of the Task you want to add to this Sprint. ");
            Scanner input = new Scanner(System.in);
            String title = input.nextLine().trim();
            System.out.println("Enter the description of the Task you want to add to this Sprint. ");
            Scanner input1 = new Scanner(System.in);
            String description = input1.nextLine().trim();
            Task task = new Task(title, description);
            tasks.add(task);                           /*Add the task to the task arraylist of the sprint */
            int task_number_in_the_sprint = tasks.size();
            System.out.println("The task of number " + task_number_in_the_sprint+ " in this sprint was created successfully. ");
            boolean invalid_input = true;
            while (invalid_input) /* to ensure the validty of the input */
            {
                System.out.println("Would you like to add more tasks? ( yes / no) ");
                Scanner input2 = new Scanner(System.in);
                String choice = input2.nextLine().trim();
                if(choice.equalsIgnoreCase("yes"))
                {
                    invalid_input = true;
                }
                else if(choice.equalsIgnoreCase("no"))
                {
                    window_open = false;
                    invalid_input = false;
                }
                else
                {
                    System.out.println("You have entered an invalid input. Try Again. ");
                }
            }

        }
    }

    public void assignTeam(ScrumMaster scrumMaster) 
    {
        System.out.println("Enter the name of the team you want to assign this sprint to.");
        Scanner input = new Scanner(System.in);
        String team_name = input.nextLine().trim();
        assignedTeam = team_name;
        System.out.println(scrumMaster.getName() + " assigned to the sprint team " + assignedTeam );
    }

    public void setdates() /* to set the dates automatically */
    {
        startDate = new Date();
        System.out.println("Enter the period of this Sprint in days.");
        Scanner input = new Scanner(System.in);
        int sprint_period = input.nextInt();
        Calendar calendar = Calendar.getInstance();
        calendar.add (Calendar.DATE, 7);
        endDate = calendar.getTime();
    }

    public void set_epics() /* to add epics to the sprint */
    {
        boolean window_open = true;
        while(window_open) /* to make the user choose if he wants to keep the window of adding epics opened */
        {
            System.out.println("Enter the title of the Epic you want to add to this Sprint. ");
            Scanner input = new Scanner(System.in);
            String title = input.nextLine().trim();
            System.out.println("Enter the description of the Epic you want to add to this Sprint. ");
            Scanner input1 = new Scanner(System.in);
            String description = input1.nextLine().trim();
            Epic epic = new Epic(title, description);
            epics.add(epic);                           /*Add the epic to the epic arraylist of the sprint */
            int epic_number_in_the_sprint = epics.size();
            System.out.println("The epic of number " + epic_number_in_the_sprint+ " in this sprint was created successfully. ");
            boolean invalid_input = true;
            while (invalid_input) /* to ensure the validty of the input */
            {
                System.out.println("Would you like to create more epics? ( yes / no) ");
                Scanner input2 = new Scanner(System.in);
                String choice = input2.nextLine().trim();
                if(choice.equalsIgnoreCase("yes"))
                {
                    invalid_input = false;
                }
                else if(choice.equalsIgnoreCase("no"))
                {
                    window_open = false;
                    invalid_input = false;
                }
                else
                {
                    System.out.println("You have enterd an invalid input. Try Again. ");
                }
            }

        }
    }
    
    public void assignTask()  /* to assign the tasks in the sprint to developers */
    {
        boolean assignTask_window = true;
        while(assignTask_window)   /* to keep the window open until the scrum Master closes it */
        {
            System.out.println("Enter the number of the task you want to assign to a developer.");
            Scanner input = new Scanner(System.in);
            int task_number = input.nextInt();
            if ( 0 < task_number && task_number <= tasks.size())
            {
                Task task = tasks.get(task_number -1);    /* the task that will be assigned to the user */
                boolean DeveloperExistInSystem = false;
                System.out.println("Enter the name of the developer you want to assign this task to.");
                Scanner scanner = new Scanner(System.in);
                String developer_name = scanner.nextLine().trim();
                for(int i = 0 ; i < ((Database.getUsers()).size()) ; i++) /* for loop to check if the developer name exists in the Database in the developer Arraylist */
                {
                    if (Database.getUsers().get(i) instanceof Developer)
                    {

                        Developer developer = (Developer) (Database.getUsers()).get(i);
                        if ((developer.getName()).equalsIgnoreCase(developer_name))  /* in case the developer exists in the Database in the developer ArrayList*/
                        {
                            DeveloperExistInSystem = true;
                            developer.set_task_assigned(task);                      /* assign task to the developer */
                            TasksAssignedToDeveloper.add(task);
                            System.out.println("Task number "+ task_number + " was assigned to developer "+ developer.getName());
                        }

                    }

                }
                if (DeveloperExistInSystem == false)
                {
                    System.out.println("This developer does not exist.");
                }
            }
            else if ( task_number <= 0)
            {
                System.out.println("You have entered an invalid input. Try Again.");
            }
            else
            {
                System.out.println("This task is not created yet.");
            }

            boolean invalid = true;
            while(invalid)            /* to check the validity of the choice */
            {
                System.out.println("Would you like to assign task again. ( yes , no )");
                Scanner input1 = new Scanner(System.in);
                String choice = input1.nextLine().trim();
                if (choice.equalsIgnoreCase("yes"))
                {
                    assignTask_window = true;
                    invalid = false;
                }
                else if (choice.equalsIgnoreCase("no"))
                {
                    assignTask_window = false;
                    invalid = false;
                }
                else
                {
                    invalid = true;
                    System.out.println("You have entered invalid input. Try again");
                }
            }
        }
    }

    @Override
    public void ChangeTaskStatus()                      
    {
        if (TasksAssignedToDeveloper.size() == 0)                  /* to check if there are tasks assigned to developers in this sprint */
        {
            System.out.println("No tasks are assigned in this Sprint to developers yet.");
        }
        else
        {
            boolean ChangeTaskStatus_Window = true;
            System.out.println("These are the tasks that are assigned to developers in this sprint.");
            System.out.println("\n");
            for( int i = 0 ; i < TasksAssignedToDeveloper.size() ; i++)  /* show the developer his assigned tasks so he choose from them */
            {
                System.out.println( i+1 + ". " +"Task: " + TasksAssignedToDeveloper.get(i).getTitle() + "              Status: " + TasksAssignedToDeveloper.get(i).get_TaskStatus() + "                          Developer assigned: " + TasksAssignedToDeveloper.get(i).get_DeveloperAssigned()) ;
            }
            System.out.println("\n");

            while(ChangeTaskStatus_Window)                      /* to keep the window of change task status opened until the Scrum Master closes it */
            {
                System.out.println("Choose the number of the task you want to change its status.");
                Scanner input = new Scanner(System.in);
                int choice = input.nextInt();
                boolean invalid =  true;
                while (invalid)                                 /* to check the validity of Scrum Master choice */
                {
                    System.out.println("You can change the task status to ( Open or Close ). Choose one of those. ");
                    Scanner scanner = new Scanner(System.in);
                    String StatusChange = scanner.nextLine();
                    if (StatusChange.equalsIgnoreCase("Open") || StatusChange.equalsIgnoreCase("Close"))       /* to check the validity of the user choice */
                    {
                        (TasksAssignedToDeveloper.get(choice -1)).set_TaskStatus(StatusChange);   /* change the status of the task */
                        invalid = false;
                    }
                    else
                    {
                        System.out.println("You have entered and invalid input. Try Again");
                        invalid = true;
                    }
                }

                boolean invalid1 = true;
                while(invalid1)                               /* to check the validity of Scrum Master choice */
                {
                    System.out.println("Would you like to change more tasks status? ( yes / no )");
                    Scanner scanner1 = new Scanner(System.in);
                    String choice1 = scanner1.nextLine().trim();
                    if (choice1.equalsIgnoreCase("yes"))
                    {
                        ChangeTaskStatus_Window = true;
                        invalid1 = false;
                    }
                    else if (choice1.equalsIgnoreCase("no"))
                    {
                        ChangeTaskStatus_Window = false;
                        invalid1 = false;
                    }
                    else
                    {
                        System.out.println("You have entered invalid input. Try Again.");
                        invalid1 = true;
                    }
                }  
            }
        }
    }
    
}