package ENTITY.User;

public class QAEngineer extends TechnicalStaff {

    public QAEngineer(String name, String username, String password) {
        super(name, username, password);
    }

}

