package ENTITY.User;
import java.util.ArrayList;
import Database.Database;
public class Stakeholder extends User {
    private int request_number;

    public Stakeholder(String name, String username, String password) {
        super( name, username, password);
    }

    public void createRequest(String request){
        request_number = Database.addRequest(request);/* to get the number of the request in the system */
        System.out.println(getUsername()+" Created a project request no. " + request_number );
       
    }
    public void viewRequest( int request_number){
        ArrayList<String> requests = Database.getRequests();
        System.out.println(requests.get(0)); /*print the request */
    }
}
