package ENTITY.User;
import java.util.Date;
import java.util.Scanner;
import java.util.Calendar;
import java.util.ArrayList;

import Database.Database;
import ENTITY.Sprint.Sprint;
import ENTITY.WorkItem.*;
public class ScrumMaster extends User
{

    public ScrumMaster( String name, String username, String password) 
    {
        super(name, username, password);
    }

    public int planSprint()  /* allow the scrum master to plan Sprint */
    {
        System.out.println("Enter the objective of the Sprint");
        Scanner input = new Scanner(System.in);
        String objective = input.nextLine().trim();
        Sprint sprint = new Sprint(objective);
        ArrayList<Sprint> sprints = Database.getSprints();
        int number_of_sprint_just_created = sprints.size();
        System.out.println("You just created sprint number " + number_of_sprint_just_created);
        return number_of_sprint_just_created;
    }



}
