package ENTITY.User;
import java.util.ArrayList;
import java.util.Scanner;

import ENTITY.WorkItem.*;

public class Developer extends TechnicalStaff implements TaskStatus {
    private ArrayList <Task> tasks_assigned = new ArrayList<>();

    public Developer(String name, String username, String password) {
        super(name, username, password);

    }
    public Developer() {}
    public void fixBug() 
    {
        System.out.println(getUsername() + " fixed a bug.");
    }

    public void implementFeature() 
    {
        System.out.println(getUsername() + " implemented a new feature.");
    }

    public void set_task_assigned(Task task)
    {
        tasks_assigned.add(task);
        task.set_DeveloperAssigned(this);
    }

    /* to allow the developer to change the status of the tasks assigned to him */
    @Override
    public void ChangeTaskStatus()                      
    {
        if (tasks_assigned.size() == 0)                  /* to check if there are tasks assigned to the user */
        {
            System.out.println("No tasks are assigned to you yet.");
        }
        else
        {
            boolean ChangeTaskStatus_Window = true;
            System.out.println("These are your tasks.");
            System.out.println("\n");
            for( int i = 0 ; i < tasks_assigned.size() ; i++)  /* show the developer his assigned tasks so he choose from them */
            {
                System.out.println( i+1 + ". " +"Task: " + tasks_assigned.get(i).getTitle() + "  Status: " + tasks_assigned.get(i).get_TaskStatus());
            }
            System.out.println("\n");

            while(ChangeTaskStatus_Window)                      /* to keep the window of change task status opened until the developer closes it */
            {
                System.out.println("Choose the number of the task you want to change its status.");
                Scanner input = new Scanner(System.in);
                int choice = input.nextInt();
                boolean invalid =  true;
                while (invalid)                                 /* to check the validity of developer choice */
                {
                    System.out.println("You can change the task status to ( In Progress or Done ). Choose one of those. ");
                    Scanner scanner = new Scanner(System.in);
                    String StatusChange = scanner.nextLine().trim();
                    if (StatusChange.equalsIgnoreCase("In Progress") || StatusChange.equalsIgnoreCase("Done"))       /* to check the validity of the user choice */
                    {
                        (tasks_assigned.get(choice -1)).set_TaskStatus(StatusChange);   /* change the status of the task */
                        invalid = false;
                    }
                    else
                    {
                        System.out.println("You have entered and invalid input. Try Again");
                        invalid = true;
                    }
                }

                boolean invalid1 = true;
                while(invalid1)                               /* to check the validity of developer choice */
                {
                    System.out.println("Would you like to change more tasks status? ( yes / no )");
                    Scanner scanner1 = new Scanner(System.in);
                    String choice1 = scanner1.nextLine().trim();
                    if (choice1.equalsIgnoreCase("yes"))
                    {
                        ChangeTaskStatus_Window = true;
                        invalid1 = false;
                    }
                    else if (choice1.equalsIgnoreCase("no"))
                    {
                        ChangeTaskStatus_Window = false;
                        invalid1 = false;
                    }
                    else
                    {
                        System.out.println("You have entered invalid input. Try Again.");
                        invalid1 = true;
                    }
                }  
            }
        }
    }
    
    /* to allow user to review the tasks assigned  to him */
    public void ReviewTasks()
    {
        if (tasks_assigned.size() == 0)                  /* to check if there are tasks assigned to the developer */
        {
            System.out.println("No tasks are assigned to you yet.");
        }
        else
        {
            System.out.println("These are your tasks.");
            System.out.println("\n");
            for( int i = 0 ; i < tasks_assigned.size() ; i++)  /* show the developer his assigned tasks so he choose from them */
            {
                System.out.println( i+1 + ". " + "Task: " + tasks_assigned.get(i).getTitle() + "                Status: " + tasks_assigned.get(i).get_TaskStatus());
            }
            System.out.println("\n");
        }
        
    }

}
