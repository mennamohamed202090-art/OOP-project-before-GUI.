package ENTITY.User;

public abstract class TechnicalStaff extends User {
    public TechnicalStaff() {
        super();
    }
    public TechnicalStaff(String name, String username, String password) {
        super(name, username, password);
    }

    public void updateTaskStatus() {
        System.out.println(getUsername() + " updated a task status.");
    }

    public void reviewCode() {
        System.out.println(getUsername() + " reviewed code.");
    }
}

