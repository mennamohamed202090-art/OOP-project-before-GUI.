package ENTITY.User;
import Database.Database;
public abstract class User {
    private static int  id_generator;
    protected int id;
    private String name;
    private String username;
    private String password;
    public User (){}
    public User(String name, String username, String password) {
        this.id = id_generator +1;
        this.name = name;
        this.username = username;
        this.password = password;
        add_user_to_users_ArrayList(this);
        id();
    }

    public void add_user_to_users_ArrayList(User user)
    {
        Database.addUser(user);
    }



    public static int id() /*to set the id automatically */
    {
        id_generator +=1;
        return id_generator;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}

