package Database;
import ENTITY.User.*;
import ENTITY.WorkItem.*;
import ENTITY.Sprint.*;
import java.util.ArrayList;

public class Database {
    private static ArrayList<String> requests = new ArrayList<>();
    private static ArrayList<User> users = new ArrayList<>();
    private static ArrayList<Epic> epics = new ArrayList<>();
    private static ArrayList<Story> stories = new ArrayList<>();
    private static ArrayList<Task> tasks = new ArrayList<>();
    private static ArrayList<Bug> bugs = new ArrayList<>();
    private static ArrayList<Sprint> sprints = new ArrayList<>();
    private static ArrayList<Developer> developers = new ArrayList<>();

    public static ArrayList<String> getRequests() { return requests; }
    public static ArrayList<User> getUsers() { return users; }
    public static ArrayList<Epic> getEpics() { return epics; }
    public static ArrayList<Story> getStories() { return stories; }
    public static ArrayList<Task> getTasks() { return tasks; }
    public static ArrayList<Bug> getBugs() { return bugs; }
    public static ArrayList<Sprint> getSprints() { return sprints; }
    public static ArrayList<Developer> getDevelopers() { return developers; }

    public static int addRequest(String request)
    {
        requests.add(request);
        int request_number = requests.size();
        return request_number;
    }
    public static void addUser(User user) { users.add(user); }
    public static void addEpic(Epic epic) { epics.add(epic); }
    public static void addStory(Story story) { stories.add(story); }
    public static void addTask(Task task) { tasks.add(task); }
    public static void addBug(Bug bug) { bugs.add(bug); }
    public static void addSprint(Sprint sprint) { sprints.add(sprint); }

    public static void printSummary() {
        System.out.println("Users: " + users.size());
        System.out.println("Epics: " + epics.size());
        System.out.println("Stories: " + stories.size());
       System.out.println("Tasks: " + tasks.size());
        System.out.println("Bugs: " + bugs.size());
        System.out.println("Sprints: " + sprints.size());
    }
}


